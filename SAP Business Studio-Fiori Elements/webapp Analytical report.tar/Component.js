sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend('ns.analyticalapplication.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
