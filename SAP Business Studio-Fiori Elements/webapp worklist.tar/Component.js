sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend('ns.worklistapplication.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
