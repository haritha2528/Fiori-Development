sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function (Controller, MessageToast) {
	"use strict";

	return Controller.extend("ns.layouteditor.controller.BasicLayout", {
		onInit: function () {

		},
		onLogin: function () {

			var oUserName = this.getView().byId("Userid").getValue();
			var oPwd = this.getView().byId("Pwd").getValue();
			if (oUserName === oPwd) {
				MessageToast.show("You are successfully logged");
			} else {
				MessageToast.show("Check your UserName & Password");
			}

		}
	});
});