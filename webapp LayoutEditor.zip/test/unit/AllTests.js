sap.ui.define([
	"ns/layouteditor/test/unit/controller/BasicLayout.controller"
], function () {
	"use strict";
});