/*global QUnit*/

sap.ui.define([
	"ns/layouteditor/controller/BasicLayout.controller"
], function (Controller) {
	"use strict";

	QUnit.module("BasicLayout Controller");

	QUnit.test("I should test the BasicLayout controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});