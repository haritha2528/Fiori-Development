sap.ui.define([
	"ns/LoginApp/test/unit/controller/login.controller"
], function () {
	"use strict";
});