sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (Controller,MessageBox,MessageToast ) {
	"use strict";

	return Controller.extend("ns.LoginApp.controller.login", {
		onInit: function () {

		},
		onLoginPress:function(oEvent){
		//	var oBtn= oEvent.getSource();
			var oUser= this.getView().byId("userid").getValue();
			var oPwd = this.getView().byId("pwd").getValue();
			
			if (oUser===oPwd){
				sap.m.MessageBox.success("you are logged in.");
			}
				else{
					sap.m.MessageBox.error("you verify username and password.");
				}
			},
			onSignupPress: function(){
				MessageToast.show("Thanku for sigining up");
			},
			
		//}
	});
});