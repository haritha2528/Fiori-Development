sap.ui.define([
	"ns/HTML5ModuleFiori/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
