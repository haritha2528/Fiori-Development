jQuery.sap.declare("ns.worklist.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ns.worklist.Component", {
	metadata: {
		"manifest": "json"
	}
});