sap.ui.define(["sap/ui/generic/app/AppComponent"], function (AppComponent) {
	return AppComponent.extend("ns.Analyticallistpage.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});